package com.example.asynctask;

import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

public class Asyncdata extends AsyncTask<String,Integer,String> {


    Context localContext;
    AlertDialog.Builder builder;

    public Asyncdata(MainActivity globalContext) {
        localContext = globalContext;
    }

    @Override
    protected String doInBackground(String... strings) {
        String data = strings[0];
        try {
            Thread.sleep(2000);
        }
        catch (InterruptedException e){
            throw new RuntimeException(e);
        }
        return data;
    }


    @Override
    protected void onPreExecute() {

        builder = new AlertDialog.Builder(localContext);
    }

    @Override
    protected void onPostExecute(String data) {

        //We can also use toast
        // Toast.makeText(localContext, data, Toast.LENGTH_SHORT).show();
        builder.setMessage(data)
                .setTitle("AsyncTaskExample")
                .setCancelable(true)
                .setIcon(R.drawable.ic_launcher_background)
                .show();


    }
}


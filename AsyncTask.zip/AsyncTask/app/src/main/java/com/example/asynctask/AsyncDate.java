package com.example.asynctask;

public class AsyncDate {
    public AsyncDate(MainActivity mainActivity) {
    }
}
